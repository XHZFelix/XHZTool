//
//  NSString+MD5.h
//  KDWFinancial
//
//  Created by 修怀忠 on 2017/8/29.
//  Copyright © 2017年 修怀忠. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

- (NSString *)md5Str;

@end
